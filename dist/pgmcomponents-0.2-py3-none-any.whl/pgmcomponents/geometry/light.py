"""
A library of classes for modelling light rays and beams.

Based on, in parts, the work of Matthew Hand's dls-optics-core package

Author: Patrick Wang
Email: patrick.wang@diamond.ac.uk

Version: 0.1
Date: 2023-09-15

"""


